import os, sys

class CreateIG:
    def __init__(self) -> None:
        self.TahapPengembang()
        pass
        
    def TahapPengembang(self):
        try: os.system('clear'); sys.exit('[#] MENU MASIH DALAM PENGEMBANG MOHON BERSABAR')
        except (Exception) as e: pass
        